// javascript file running on frontend

var urlObject=Qs.parse(location.search,{ignoreQueryPrefix:true});
var {userName,roomName}=urlObject;


var socket=io();
socket.emit("joinChat",urlObject);

socket.on("newUserJoin",(dataObj)=>{
    var messagesDiv=document.getElementById("chatMessagesDiv");
    var para=document.createElement("p");
    var text=document.createTextNode("A new user "+ dataObj.userName + " has joined");
    para.appendChild(text);
    messagesDiv.appendChild(para);
})

socket.on("addMessage",(dataObj)=>{
    var messagesDiv=document.getElementById("chatMessagesDiv");
    var para=document.createElement("p");
    var text=document.createTextNode(dataObj.userName + ": "+dataObj.message);;
    para.appendChild(text);
    messagesDiv.appendChild(para);
})
function sendMsgEventHandler(event)
{
    
    var message=document.getElementById("chatMsg").value;
    var messageTextBox=document.getElementById("chatMsg");
    messageTextBox.value="";
    socket.emit("newMessage",{message:message,userName,roomName});
}

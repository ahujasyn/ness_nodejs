var usersArr=[];

function addUser(userName,roomName,socket)
{
    usersArr.push({userName,roomName,socket});
}

module.exports={addUser};
var fs=require("fs");

// streams -- constant flow of data; huge amounts of data-- break it into chunks
// stream -- read, write, duplex

// readStream -- reading from the stream
// reading from a file;
//notified  when a chunk of file has been read;
// notified when all the chunks or complete file is read
// notified if there is an error if reading a file
// data is broken up into chunks 
// default chunk size --64 kilobytes
// chunk size is also configurable
var numberOfChunks=0;
// highWaterMark is used to configure the chunk size, give the value in bytes
// open the stream for reading a file

var readStream=fs.createReadStream("file2.txt",{highWaterMark:1024});

// whenever the chunk is read by the readStream, it will emit an event called as "data"
// data event is triggered multiple time based on size of file
readStream.on("data",(chunk)=>{
    numberOfChunks++;
    //console.log("Chunk :",chunk.toString());
})


// whenever all the chunks have been read by the readStream(ih has reached the end of reading the file), it will emit an event called as "end"
// end event will be triggered only once
readStream.on("end",()=>{
    console.log("Number of chunks",numberOfChunks);
    console.log("Reading of file successfully completed");
    // automatically closes the stream
})

// whenever there is an error encountered  by the readStream, it will emit an event called as "error"
readStream.on("error",(err)=>{
    console.log("Error :",err);
})
console.log("bye");


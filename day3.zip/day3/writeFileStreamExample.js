var fs=require("fs");

// whenever we want to write into  a stream
var writeStream=fs.createWriteStream("file3.txt");

// write data into a file on a continuous basis
// write huge data
// write multiple times

// write multiple times
// when finished, tell them that the write is complete
// close the stream
//Once closed, if we try to write -- throw an error
// triggering the events
writeStream.write("Today is a beautiful day",(err)=>{
    if(err)
        {
            console.log("Error in write operation ",err);
            // this is executed before the error event is triggered
        }
    else
    {
        // data is written successfully, perform other operations based on the write
    }
});

writeStream.write("Ness has an at-scale global delivery footprint and offers its digital engineering services from locations in North America, Europe, and India. We have been perfecting a form of globally distributed agile development called Flexshoring for the last 20 years across 11 innovation hubs in Pittsburgh, Iasi, Timisoara, Kosice, Riga, Bangalore, Mumbai, Pune, Hyderabad, Prague, and Tel Aviv. Due to the nature of business, Ness has processes in place to ensure innovation and collaboration are sustained in a virtual space through various channels.");

writeStream.write("This is last line of the file");

writeStream.end("This is part of end method call");// trigger the end event;
// writeStream.write("This is not going to be written in the file",(err)=>{
//     if(err)
//         {
//             console.log("Error in write operation ",err);
//             // this is executed before the error event is triggered
//         }

// });
writeStream.on("error",(err)=>{
    console.log("Error as part of error event",err);
})

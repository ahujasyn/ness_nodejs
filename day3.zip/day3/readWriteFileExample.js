// read from a big file and write into another file

//
var fs=require("fs");

var numberOfChunks = 0;

var readstream = fs.createReadStream("file1.txt");
var writeStream =  fs.createWriteStream("file4.txt");


readstream.on("data",(chunk)=>{
    numberOfChunks++;
    if(chunk){
        writeStream.write(chunk,(err)=>{
            if(err)
        {
            console.log("Error in write operation ",err);
        }
        });
    }
    //console.log("Chunk :",chunk.toString());
});

readstream.on("end",()=>{
    writeStream.end();
    console.log(numberOfChunks);
    console.log("Reading of file successfully completed");
    console.log("Writing of file successfully completed");
});

readstream.on("error",(err)=>{
    console.log("Error :",err);
});

writeStream.on("error",(err)=>{
    console.log("Error as part of error event",err);
})

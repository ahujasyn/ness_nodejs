// read from a big file and write into another file

//
var fs=require("fs");

var numberOfChunks = 0;

var readstream = fs.createReadStream("file1.txt");
var writeStream =  fs.createWriteStream("file5.txt");
readstream.pipe(writeStream);

/*
Linux
ls | grep *.txt

*/


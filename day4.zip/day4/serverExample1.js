var http = require("http");// core module
var fs = require("fs");
var url = require("url");
var querystring = require("querystring");
const port = 3000;
// request from the client which will be handled by server
// http requests -- GET(select), POST(insert), PUT(update),DELETE(delete)
// request will contain: url, body(optional), query string, content-type, authentication information, header info
// server -- handle the request and give a response back
// response will contain: data, body, header information, status code, Content-type, cookies, cache

// server -- host name, port
var empArr = [{ empId: 101, empName: "Sara", projectId: "P101" },
{ empId: 102, empName: "Keshav", projectId: "P101" },
{ empId: 103, empName: "Saurabh", projectId: "P102" },
{ empId: 104, empName: "Giri", projectId: "P102" },
{ empId: 105, empName: "Saraansh", projectId: "P103" },
{ empId: 106, empName: "Piyush", projectId: "P104" },
{ empId: 107, empName: "Neha", projectId: "P104" },
{ empId: 108, empName: "Priyam", projectId: "P105" },
{ empId: 109, empName: "Pranav", projectId: "P105" },
{ empId: 110, empName: "Puja", projectId: "P104" }]

function requestListener(request, response) {
    console.log(request.url);
    var urlObject = url.parse(request.url);// convert the url into an object format
    console.log(urlObject);
    var queryStringObject = querystring.parse(urlObject.query);
    console.log(queryStringObject);
    if (request.method == "GET") {
        if (request.url == "/") {
            // display a html page or file which is .html
            // write a string "index.html"
            // pure server side rendering
            // send the contents of index.html
            fs.readFile("index.html", (err, data) => {
                if (err) {
                    // status code in 400
                    response.writeHead(401, "Error in loading the page");
                    response.end();
                }
                else {
                    response.write(data);
                    response.end();

                }
            })
            return;
        }
        if (request.url == "/login") {
            //send the login page
            var readStream = fs.createReadStream("login.html", { highWaterMark: 1024 });

            readStream.on("data", (chunk) => {
                response.write(chunk);

            })


            readStream.on("end", () => {
                // automatically closes the stream
                response.end();
                return;
            })

            // whenever there is an error encountered  by the readStream, it will emit an event called as "error"
            readStream.on("error", (err) => {
                console.log("Error :", err);
                response.writeHead(401, err);
                response.end();
            })
        }
        if (request.url == "/image") {
            // send an image
            var readStream = fs.createReadStream("thanks.jpg");
            readStream.pipe(response);
        }
        if (request.url == "/employee") {
            // send a json response -empArr;
            response.writeHead(200, { "Content-Type": "application/json" });
            response.write(JSON.stringify(empArr));
            response.end();

        }
        if (urlObject.pathname == "/products") {
            response.write(JSON.stringify(queryStringObject));
            response.end();
        }
        response.write("Thank u for contacting the server");
        response.write("Have a nice day");
        response.end();// no more write is going to happen on the stream

    }
    else
        if (request.method == "POST") {
            // get some data for insertion
            // data as part of body
            if (request.url == "/employee") {
                // get the record from the body 
                // request -- stream of data; read the stream
                var insertRecord = "";
                var ctr = 0;
                request.on("data", (chunk) => {
                    insertRecord += chunk;


                })
                request.on("end", () => {
                    insertRecord = JSON.parse(insertRecord);
                    empArr.push(insertRecord);
                    response.write(JSON.stringify(empArr));
                    response.end();
                })
            }
        }
        else
            if (request.method == "PUT") {
                if (request.url == "/employee") {
                    //data is coming in body section
                    var updatedRecord = "";
                    request.on("data", (chunk) => {
                        updatedRecord += chunk;
                    })
                    request.on("end", () => {
                        updatedRecord = JSON.parse(updatedRecord);
                        var pos = empArr.findIndex(item => item.empId == updatedRecord.empId);
                        if (pos >= 0) {
                            empArr[pos] = updatedRecord;
                            response.end(JSON.stringify(empArr));
                        }
                        else {
                            response.end("Employee with the employee Id: " + updatedRecord.empId + " not found");
                        }
                    })
                }
            }
            else {
                response.write("Thank u for contacting the server");
                response.write("Have a nice day");
                response.end();// no more write is going to happen on the stream
            }






}
var app = http.createServer(requestListener);
app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
})



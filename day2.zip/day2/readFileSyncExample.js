var fs=require("fs");

try
{
console.log("Hello");
var data=fs.readFileSync("file.txt");
console.log(data);

}
catch(ex)
{
    console.log("Exception occurred while reading the file");
}
finally
{
    console.log("bye");
}
// hello data bye 


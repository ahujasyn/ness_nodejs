var { MongoClient } = require("mongodb");

var connectionString = "mongodb://127.0.0.1:27017/";

const mongoClient = new MongoClient(connectionString);
async function insertAProduct(productToBeInserted) {
    console.log("Inside the controller function insertAProduct");
    var result = {};
    try {

        // connect to the db and do an insert operation
        var client = await mongoClient.connect();
        console.log("Connection to the db successful");
        // connect to the db nessDb
        var dbName = client.db("nessDb");
        var collName = dbName.collection("products");
        var resultOfOperation = await collName.insertOne(productToBeInserted);
        console.log("Result of insertOne", resultOfOperation);
        if (resultOfOperation.insertedId) {
            result.statusCode = 200;
            result.msg = "Product inserted successfully with inserted Id :" + resultOfOperation.insertedId.toString();
            
        }
        else {
            result.statusCode = 401;
            result.msg = "Product insertion failed"
        }
    }
    catch (exception) {
        result.statusCode = 500;
        result.msg = "Internal error";
        console.log("Error in insertOne", exception);
    }
    finally {
        mongoClient.close();
        return result;

    }



}

async function getAllProducts(request, response) {
    var result = {};
    try {

        // connect to the db and do an insert operation
        var client = await mongoClient.connect();
        console.log("Connection to the db successful");
        // connect to the db nessDb
        var dbName = client.db("nessDb");
        var collName = dbName.collection("products");
        var cursor = collName.find();
        var productsArr = await cursor.toArray();
        if (productsArr) {
            result.statusCode = 200;
            result.msg = productsArr;
        }
        else {
            result.statusCode = 401;
            result.msg = "Get request failed"
        }
    }
    catch (exception) {
        result.statusCode = 500;
        result.msg = "Internal error";
        console.log("Error in insertOne", exception);
    }
    finally {
        mongoClient.close();
        response.status(result.statusCode).json(result.msg);

    }
}

async function getProduct(searchProductId) {
    var result = {};
    try {

        // connect to the db and do an insert operation
        var client = await mongoClient.connect();
        console.log("Connection to the db successful");
        // connect to the db nessDb
        var dbName = client.db("nessDb");
        var collName = dbName.collection("products");
        var selectionDoc = { productId: searchProductId };
        var projectionDoc = { _id: 0 };
        var resultOfOperation = await collName.findOne(selectionDoc, { projection: projectionDoc });
        if (resultOfOperation) {
            result.statusCode = 200;
            result.msg = resultOfOperation;
        }
        else {
            result.statusCode = 200;
            result.msg = `Product with ProductId ${searchProductId} not found`;
        }
    }
    catch (exception) {
        result.statusCode = 500;
        result.msg = "Internal error";
        console.log("Error in insertOne", exception);
    }
    finally {
        mongoClient.close();
        return result;

    }

}

async function updateProduct(productToBeUpdated, productIdToBeUpdated) {
    var result = {};
    try {

        // connect to the db and do an insert operation
        var client = await mongoClient.connect();
        console.log("Connection to the db successful");
        // connect to the db nessDb
        var dbName = client.db("nessDb");
        var collName = dbName.collection("products");
        var searchDoc = { productId: productIdToBeUpdated };
        var updateDoc = { $set: { price: productToBeUpdated.price } };
        var resultOfOperation = await collName.updateOne(searchDoc, updateDoc);
        console.log("Result of updateOne",resultOfOperation);
        if (resultOfOperation) {
            if (resultOfOperation.matchedCount == 1 && resultOfOperation.modifiedCount == 1) {
                result.statusCode = 200;
                result.msg = "Price successfully modified"
            }
            else
            if (resultOfOperation.matchedCount == 1 && resultOfOperation.modifiedCount == 0) {
                result.statusCode = 200;
                result.msg = "Product found but no modifications needed"
            }
            else
            if (resultOfOperation.matchedCount == 0 ) {
                result.statusCode = 200;
                result.msg = `Product with ProductId ${productIdToBeUpdated} not found`
            }
        }
        else {
            result.statusCode = 401;
            result.msg = "Put request failed"
        }
        console.log("Result in controller",result);
    }
    catch (exception) {
        result.statusCode = 500;
        result.msg = "Internal error";
        console.log("Error in insertOne", exception);
    }
    finally {
        mongoClient.close();
        return result;

    }
}

async function deleteProduct(productIdToBeDeleted)
{
    var result = {};
    try {

        // connect to the db and do an insert operation
        var client = await mongoClient.connect();
        console.log("Connection to the db successful");
        // connect to the db nessDb
        var dbName = client.db("nessDb");
        var collName = dbName.collection("products");
        var selectionDoc = { productId: productIdToBeDeleted };
        var resultOfOperation = await collName.deleteOne(selectionDoc);
        if (resultOfOperation) {
            if(resultOfOperation.deletedCount ==1)
                {
                    result.statusCode = 200;
                    result.msg = `Product with ProductId ${productIdToBeDeleted} deleted`;;
                }
            else {
                    result.statusCode = 200;
                    result.msg = `Product with ProductId ${productIdToBeDeleted} not found`;
                }
            
        }
        else {
            result.statusCode = 401;
            result.msg = `Delete operation failed`;
        }
    }
    catch (exception) {
        result.statusCode = 500;
        result.msg = "Internal error";
        console.log("Error in  deleteOne", exception);
    }
    finally {
        mongoClient.close();
        return result;

    }


}
module.exports = { insertAProduct, getAllProducts, getProduct, updateProduct,deleteProduct };

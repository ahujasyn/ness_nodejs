var express=require("express");
var productRouter=express.Router();
var morgan=require("morgan");
var fs=require("fs");

var {insertAProduct,getAllProducts,getProduct,updateProduct,deleteProduct}=require("../controller/productController");

var writeStream=fs.createWriteStream("productLog.txt",{flags:"a"});


productRouter.use((req,res,next)=>{
    // middleware will be invoked only for requests coming to /products
    // use morgan to write into the stream
    next();
})
productRouter.use(morgan('combined', { stream: writeStream }))


productRouter.get("/",getAllProducts);// passing the control flow to controller
productRouter.get("/:pId",async(req,res)=>{
    // get request for a particular product
    // products/101
    var productId=parseInt(req.params.pId);
    var result=await getProduct(productId);
    res.status(result.statusCode).send(result.msg);


})
productRouter.post("/",async (req,res)=>{
    console.log("Inside post request of /products")
    // insert a record
    var productToBeInserted=req.body;
    var result=await insertAProduct(productToBeInserted);

    res.status(result.statusCode).send(result.msg);
    
})
console.log("hello");
productRouter.put("/:pId",async(req,res)=>{
    var productToBeUpdated=req.body;
    var productIdToBeUpdated=parseInt(req.params.pId);
    var result=await updateProduct(productToBeUpdated,productIdToBeUpdated);
    console.log("Result of put operation",result)
    res.status(result.statusCode).send(result.msg);

})
productRouter.delete("/:pId",async(req,res)=>{
    var productIdToBeDeleted=parseInt(req.params.pId);
    var result=await deleteProduct(productIdToBeDeleted);
    res.status(result.statusCode).send(result.msg);
})

module.exports=productRouter;

var express=require("express");
var path=require("path")
var registerRouter=express.Router();

registerRouter.get("/",(request,response)=>{
    //get request to /register 
    // send register.html
    var filePath=path.join(__dirname,"..","public","register.html")
    response.sendFile(filePath)
})

registerRouter.post("/",(request,response)=>{
    
})


module.exports=registerRouter;
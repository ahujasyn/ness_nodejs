var express=require("express");
var path=require("path")
var loginRouter=express.Router();

loginRouter.get("/",(request,response)=>{
    //get request to /login 
    // send register.html
    var filePath=path.join(__dirname,"..","public","login.html")
    response.sendFile(filePath)
})

loginRouter.post("/",(request,response)=>{

})


module.exports=loginRouter;
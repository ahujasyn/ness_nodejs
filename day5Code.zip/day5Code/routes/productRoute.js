var express=require("express");
var productRouter=express.Router();
var morgan=require("morgan");
var fs=require("fs");

var {insertAProduct,getAllProducts,getProduct,updateProduct}=require("../controller/productController");

var writeStream=fs.createWriteStream("productLog.txt",{flags:"a"});


productRouter.use((req,res,next)=>{
    // middleware will be invoked only for requests coming to /products
    // use morgan to write into the stream
    next();
})
productRouter.use(morgan('combined', { stream: writeStream }))


productRouter.get("/",getAllProducts);// passing the control flow to controller
productRouter.get("/:pId",async(req,res)=>{
    // get request for a particular product
    // products/101
    var productId=parseInt(req.params.pId);
    var result=await getProduct(productId);
    res.status(result.statusCode).send(result.msg);


})
productRouter.post("/",async (req,res)=>{
    console.log("Inside post request of /products")
    // insert a record
    var productToBeInserted=req.body;
    var result=await insertAProduct(productToBeInserted);

    res.status(result.statusCode).send(result.msg);
    
})
console.log("hello");
productRouter.put("/:pId",(req,res)=>{
    var productToBeUpdated=req.body;
    var productIdToBeUpdated=req.params.pId;
    var result=updateProduct(productToBeUpdated,productIdToBeUpdated);
    res.status(result.statusCode).send(result.msg);

})
productRouter.delete("/",(req,res)=>{})

module.exports=productRouter;

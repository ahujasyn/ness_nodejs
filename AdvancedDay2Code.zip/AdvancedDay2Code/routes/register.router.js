var express=require("express");
var path=require("path")
var registerRouter=express.Router();

var {addUser}=require("../controller/user.controller")

registerRouter.get("/",(request,response)=>{
    //get request to /register 
    // send register.html
    var filePath=path.join(__dirname,"..","public","register.html")
    response.sendFile(filePath)
})

registerRouter.post("/",(request,response)=>{
    var data=request.body;
    // add the user to the db;
    console.log("Data from the client in post to /register",data);
    if(data.userName && data.password)
        {
            var result=addUser(data.userName,data.password);
            if(result)
                {
                    //response.send("User details added successfully")
                    response.redirect("/login");
                }
            else
            {
                response.status(401).send("Username already exists");
            }
        }
    else
    {
        response.status(401).send("Username and password are not found")
    }
    // navigate to login page: get request to /login 
})


module.exports=registerRouter;
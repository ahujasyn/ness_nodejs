require("dotenv").config();
var jwt = require("jsonwebtoken");
function generateToken(userName, password, response) {
    const payload = { userName, password };
    const secret = process.env.SECRET_KEY;
    const options = { expiresIn: "5d", issuer: "http://localhost" };
    jwt.sign(payload, secret, options, (err, token) => {
        if (err) {
            //return ({msg:err,statusCode:500,status:false})
            response.status(500).send(err);
        }
        else {
            //return({msg:{token},statusCode:200,status:true});
            response.json({ token });
        }
    })
}
function generateTokenWithPromise(userName, password) {
    const payload = { userName, password };
    const secret = process.env.SECRET_KEY;
    const options = { expiresIn: "5d", issuer: "http://localhost" };
    var signPromise = new Promise((resolve, reject) => {
        jwt.sign(payload, secret, options, (err, token) => {
            if (err) {
                var errData = { msg: err, statusCode: 500, status: false };
                reject(errData);
            }
            else {
                var tokenData = { msg: { token }, statusCode: 200, status: true };
                resolve(tokenData);

            }
        })

    })
    return signPromise;

}
function validateToken(request, response, next) {

    // this is a middleware function
    // if token is present
    const authorizationHeader = request.headers.authorization;
    console.log("authorization header", authorizationHeader);
    if (authorizationHeader) {
        const token = authorizationHeader.split(" ")[1];
        const secret = process.env.SECRET_KEY;
        const options = { expiresIn: "5d", issuer: "http://localhost" };
        jwt.verify(token, secret, options, (err, result) => {
            if (err) {
                var errData = { statusCode: 401, msg: err }
            
                response.status(401).send(err);
            }
            else {
                request.result = result;
                
                next();
            }
        })



    }

}

module.exports = { generateToken, validateToken, generateTokenWithPromise }